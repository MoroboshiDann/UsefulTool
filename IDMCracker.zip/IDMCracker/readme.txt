1. 先下载IDM6.4x
2. 把txt文件中的字粘贴到powershell中
3. 回车